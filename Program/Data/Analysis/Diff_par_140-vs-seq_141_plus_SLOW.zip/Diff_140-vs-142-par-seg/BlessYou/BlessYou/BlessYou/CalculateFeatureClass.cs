﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlessYou
{
    public static class CalculateFeatureClass
    {
        // ====================================================================

        /// <summary>
        /// Calculate the absolute peak  value among the input data
        /// </summary>
        public static void CalculatePeakColumn(List<Double> i_WaveDataSamples, int i_FirstListIx, int i_Count, out List<double> o_CalculatedData)
        {
            throw new System.NotImplementedException();
        } // CalculatePeakColumn

        // ====================================================================

        /// <summary>
        /// Calculate the Mean = average value among the input data
        /// </summary>
        public static void CalculateMeanColumn(List<Double> i_WaveDataSamples, int i_FirstListIx, int i_Count, out List<double> o_CalculatedData)
        {
            throw new System.NotImplementedException();
        } // CalculateMeanColumn

        // ====================================================================

    }
}
