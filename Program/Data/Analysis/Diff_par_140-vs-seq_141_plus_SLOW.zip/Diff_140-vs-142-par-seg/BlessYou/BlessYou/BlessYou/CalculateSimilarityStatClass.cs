﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlessYou
{
    public static class CalculateSimilarityStatClass
    {
        public static void CalculateSimilarity(CaseClass i_NewProblem, List<CaseClass> i_CaseLibrary, out double o_SimularityValue)
        {

            //i_CaseLibrary[9].




            throw new System.NotImplementedException();
        }
    }
}
