﻿// FeatureExtractor.cs
//
// DVA406 Intelligent Systems, Mdh, vt15
//
// History:
// 2015-02-24   Introduced.
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlessYou
{
    class FeatureExtractor
    {

        List<CaseClass> FListOfCases;

        // ====================================================================

        void _loadFeatureList(string i_WavFileListFile_FullPathAndFileNameStr)
        { 
            // 1. Läs filenamns-listan
            // 2. För varje rad i listan:
            //      Skapa ett case med: Case.cs
            //      placera i FListOfCases

            throw new System.NotImplementedException();
        } // _loadFeatureList

        // ====================================================================
    }
}
