﻿// EnumSneezeMarker.cs
//
// DVA406 Intelligent Systems, Mdh, vt15
//
// History:
// 2015-02-24       Introduced.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BlessYou
{
    // ToDo replace!
public enum EnumSneezeMarker
    {
        smNone,
        smUnKnown,
        smNoSneeze,
        smSneeze
    } // EnumSneezeMarker
}
